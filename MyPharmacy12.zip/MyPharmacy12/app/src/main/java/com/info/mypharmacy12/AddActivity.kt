package com.info.mypharmacy12

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_add.*

class AddActivity : AppCompatActivity() {
    lateinit var da:Database
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)
        da= Database(this)
        button7.setOnClickListener { startActivity(Intent(this,MainActivity::class.java)) }
    }
    fun add (view: View){
        val name =n.text.toString()
        val qu=q.text.toString()
        val price =p.text.toString()
        val type =t.text.toString()
        if (n.text.isEmpty()||q.text.isEmpty()||p.text.isEmpty()||t.text.isEmpty()){
            Toast.makeText(this,"التاكد من ادخال البيانات",Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(this,"تم ادخال البيانات",Toast.LENGTH_SHORT).show()
            da.add(Model(0,name,qu.toInt(),price.toDouble(),type))
            n.text.clear()
            q.text.clear()
            p.text.clear()
            t.text.clear()
        }

    }
}