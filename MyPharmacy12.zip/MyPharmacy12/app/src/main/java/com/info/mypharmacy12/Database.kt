package com.info.mypharmacy12

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Database(context: Context):SQLiteOpenHelper(context, DN,null, DV) {
    companion object{
        val id ="ID"
        val name ="name"
        val quantity ="quantity"
        val price ="price"
        val type ="type"
        val DTN ="Medicine"

        private val DN ="PharmacyDB.db"
        private val DV =1
        val DC = "CREATE TABLE $DTN($id INTEGER PRIMARY KEY AUTOINCREMENT,"+
                "$name TEXT NOT NULL,"+
                "$quantity INTEGER,"+
                "$price DOUBLE,"+
                "$type TEXT NOT NULL); "
    }

    override fun onCreate(p0: SQLiteDatabase?) {
        p0!!.execSQL(DC)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        p0!!.execSQL("DROP TABLE IF EXISTS $DTN")
        onCreate(p0)
    }
    fun add (p:Model){
        val db =writableDatabase
        val v =ContentValues().apply {
            put(name,p.name)
            put(quantity,p.quantity)
            put(price,p.price)
            put(type,p.type)
        }
        db.insert(DTN,null,v)
        db.close()
    }
    fun delete(i:Int){
        val db = writableDatabase
        db.execSQL("DELETE FROM $DTN WHERE $id =\"$i\";")
        db.close()
    }

    @SuppressLint("Range")
    fun print ():ArrayList<Model>{
        val db =writableDatabase
        val dbs :ArrayList<Model>
        val q ="SELECT * FROM $DTN WHERE 1"
        val c =db.rawQuery(q,null)
        dbs=ArrayList(c.count)
        c.moveToFirst()

        if (c.moveToFirst()){
            do {
                val iid =c.getInt(c.getColumnIndex(id))
                val n =c.getString(c.getColumnIndex(name))
                val qq =c.getInt(c.getColumnIndex(quantity))
                val pp =c.getDouble(c.getColumnIndex(price))
                val t =c.getString(c.getColumnIndex(type))
                dbs.add(Model(iid,n,qq,pp,t))
            }while (c.moveToNext())
        }
        c.close()
        return dbs

    }

    @SuppressLint("Range")
    fun find (n1:String):ArrayList<Model>{
        val db =writableDatabase
        val dbs :ArrayList<Model>
        val q ="SELECT * FROM $DTN WHERE $type =\"$n1\";"
        val c =db.rawQuery(q,null)
        dbs=ArrayList(c.count)
        c.moveToFirst()

        if (c.moveToFirst()){
            do {
                val iid =c.getInt(c.getColumnIndex(id))
                val n =c.getString(c.getColumnIndex(name))
                val qq =c.getInt(c.getColumnIndex(quantity))
                val pp =c.getDouble(c.getColumnIndex(price))
                val t =c.getString(c.getColumnIndex(type))
                dbs.add(Model(iid,n,qq,pp,t))
            }while (c.moveToNext())
        }
        c.close()
        return dbs

    }
}