package com.info.mypharmacy12

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.item_layout.view.*

class MedicineAdapter(context: Context,private val m: ArrayList<Model>) :
    ArrayAdapter<Model>(context, R.layout.item_layout,m) {
    lateinit var da:Database
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        da= Database(context)
        val l = LayoutInflater.from(context)
        val c = l.inflate(R.layout.item_layout, parent, false)

        val x: Model = getItem(position)!!
        c.textView6.text = x.name
        c.textView7.text = x.quantity.toString()
        c.textView8.text = x.price.toString()

        if (x.type == "حبوب") {
            c.imageView3.setImageResource(R.drawable.hopoop)
        } else {
            if (x.type == "حقن") {
                c.imageView3.setImageResource(R.drawable.haqen)
            } else {
                if (x.type == "شراب") {
                    c.imageView3.setImageResource(R.drawable.shrab)
                }
            }
        }
    c.button4.setOnClickListener {
        m.removeAt(position)
        da.delete(x.id)
        notifyDataSetChanged()
        Toast.makeText(context,"تم الحذف",Toast.LENGTH_SHORT).show()
    }


        return c
    }
}