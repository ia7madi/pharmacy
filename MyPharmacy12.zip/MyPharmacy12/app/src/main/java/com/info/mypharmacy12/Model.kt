package com.info.mypharmacy12

class Model(  val id:Int,
              val name :String,
              val quantity:Int,
              val price:Double,
              val type :String) {
}