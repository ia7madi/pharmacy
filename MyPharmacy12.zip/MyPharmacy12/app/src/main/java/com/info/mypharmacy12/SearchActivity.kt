package com.info.mypharmacy12

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_search.*
import kotlinx.android.synthetic.main.activity_view.*

class SearchActivity : AppCompatActivity() {
    lateinit var da:Database
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        da= Database(this)
        pri()
    }
    fun pri(){
        val x =da.print()
        val a =MedicineAdapter(this,x)
        List.adapter=a
    }
    fun search(view: View){
        val x =serch.text.toString()
        val x1=da.find(x)
        val a =MedicineAdapter(this,x1)
        List.adapter=a
    }
}